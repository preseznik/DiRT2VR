#pragma once

void XllnThreadKeepAliveStart();
void XllnThreadKeepAliveStop();
void XllnThreadKeepAliveAbandon();
