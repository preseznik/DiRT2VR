#pragma once
#include <stdint.h>

extern HWND xlln_hwnd_debug_log;

uint32_t InitXllnWndDebugLog();
uint32_t UninitXllnWndDebugLog();
